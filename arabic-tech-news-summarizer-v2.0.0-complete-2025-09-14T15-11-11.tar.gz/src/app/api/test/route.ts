import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    // Test database connection
    await db.$queryRaw`SELECT 1 as test`
    
    // Get some basic stats
    const articleCount = await db.newsArticle.count()
    const sourceCount = await db.newsSource.count()
    const categoryCount = await db.category.count()
    const tagCount = await db.tag.count()

    return NextResponse.json({
      status: 'success',
      message: 'Database connection successful',
      data: {
        articles: articleCount,
        sources: sourceCount,
        categories: categoryCount,
        tags: tagCount
      }
    })
  } catch (error) {
    console.error('Database test error:', error)
    return NextResponse.json({
      status: 'error',
      message: 'Database connection failed',
      error: error.message
    }, { status: 500 })
  }
}