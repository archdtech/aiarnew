import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const source = await db.newsSource.findUnique({
      where: { id: params.id }
    })

    if (!source) {
      return NextResponse.json(
        { error: 'المصدر غير موجود' },
        { status: 404 }
      )
    }

    // Test the RSS feed
    if (!source.rssUrl) {
      return NextResponse.json({
        message: 'المصدر لا يحتوي على رابط RSS',
        success: false
      })
    }

    try {
      const response = await fetch(source.rssUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; TechNewsBot/1.0)'
        }
      })

      if (!response.ok) {
        return NextResponse.json({
          message: `فشل في الوصول إلى RSS: ${response.statusText}`,
          success: false
        })
      }

      const rssText = await response.text()
      
      // Simple RSS validation
      const hasItems = rssText.includes('<item>')
      const hasChannel = rssText.includes('<channel>')
      const hasTitle = rssText.includes('<title>')

      const isValid = hasItems && hasChannel && hasTitle

      return NextResponse.json({
        message: isValid ? 'RSS صالح ويعمل بشكل صحيح' : 'RSS قد يحتوي على مشاكل',
        success: isValid,
        details: {
          hasItems,
          hasChannel,
          hasTitle,
          responseStatus: response.status,
          contentLength: rssText.length
        }
      })
    } catch (error) {
      return NextResponse.json({
        message: `فشل في اختبار RSS: ${error}`,
        success: false
      })
    }
  } catch (error) {
    console.error('Error testing source:', error)
    return NextResponse.json(
      { error: 'فشل في اختبار المصدر' },
      { status: 500 }
    )
  }
}