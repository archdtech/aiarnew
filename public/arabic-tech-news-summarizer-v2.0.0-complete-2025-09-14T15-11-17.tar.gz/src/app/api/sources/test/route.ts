import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const { rssUrl } = await request.json()

    if (!rssUrl) {
      return NextResponse.json(
        { error: 'رابط RSS مطلوب' },
        { status: 400 }
      )
    }

    // Test RSS feed
    const response = await fetch(rssUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; TechNewsBot/1.0)'
      }
    })

    if (!response.ok) {
      return NextResponse.json({
        success: false,
        message: `فشل في الوصول إلى مصدر RSS: ${response.statusText}`
      })
    }

    const rssText = await response.text()
    
    // Simple RSS validation
    const hasRSS = rssText.includes('<rss') || rssText.includes('<feed')
    const hasItems = rssText.includes('<item') || rssText.includes('<entry')
    
    if (!hasRSS) {
      return NextResponse.json({
        success: false,
        message: 'الرابط لا يحتوي على مصدر RSS صالح'
      })
    }

    // Count items
    const itemMatches = rssText.match(/<item>/g) || rssText.match(/<entry>/g) || []
    const itemCount = itemMatches.length

    return NextResponse.json({
      success: true,
      message: `مصدر RSS صالح يحتوي على ${itemCount} عنصر`,
      details: {
        itemCount,
        feedSize: rssText.length,
        hasItems: hasItems
      }
    })
  } catch (error) {
    console.error('Error testing RSS:', error)
    return NextResponse.json(
      { error: 'فشل في اختبار مصدر RSS' },
      { status: 500 }
    )
  }
}