'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import SourceCodeDownloader from '@/components/download/SourceCodeDownloader'
import { 
  Download, 
  Code, 
  FolderOpen, 
  GitBranch, 
  Star,
  Users,
  Zap,
  Shield,
  Rocket,
  ArrowLeft,
  FileText,
  Package,
  Database
} from 'lucide-react'
import Link from 'next/link'

export default function DownloadPage() {
  const [projectInfo, setProjectInfo] = useState({
    name: 'ملخص التقنية',
    version: '1.0.0',
    description: 'منصة تلخيص الأخبار التقنية باللغة العربية',
    lastUpdated: new Date().toLocaleDateString('ar-SA'),
    downloadCount: 0,
    size: '2.4 MB'
  })

  const features = [
    {
      icon: <Zap className="w-6 h-6" />,
      title: 'تلقائي بالكامل',
      description: 'جلب وتلخيص وتصنيف الأخبار تلقائياً باستخدام الذكاء الاصطناعي'
    },
    {
      icon: <Code className="w-6 h-6" />,
      title: 'كود مصدر نظيف',
      description: 'كود TypeScript منظم مع أفضل الممارسات والتعليقات'
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: 'آمن وموثوق',
      description: 'يتبع معايير الأمان ويحمي البيانات الحساسة'
    },
    {
      icon: <Rocket className="w-6 h-6" />,
      title: 'جاهز للإطلاق',
      description: 'مشروع كامل جاهز للتطوير والنشر مباشرة'
    }
  ]

  const techStack = [
    { name: 'Next.js 15', category: 'Framework', icon: '🚀' },
    { name: 'TypeScript', category: 'Language', icon: '📝' },
    { name: 'Tailwind CSS', category: 'Styling', icon: '🎨' },
    { name: 'shadcn/ui', category: 'Components', icon: '🧩' },
    { name: 'Prisma', category: 'Database', icon: '🗄️' },
    { name: 'SQLite', category: 'Database', icon: '📊' },
    { name: 'z-ai-web-dev-sdk', category: 'AI', icon: '🤖' },
    { name: 'Lucide React', category: 'Icons', icon: '🎯' }
  ]

  const includedFiles = [
    { icon: <FolderOpen className="w-5 h-5" />, name: 'الكود المصدري الكامل', count: '150+ ملف' },
    { icon: <FileText className="w-5 h-5" />, name: 'التوثيق الكامل', count: 'README.md' },
    { icon: <Package className="w-5 h-5" />, name: 'إعدادات المشروع', count: 'package.json' },
    { icon: <Database className="w-5 h-5" />, name: 'قاعدة البيانات', count: 'Prisma schema' },
    { icon: <Code className="w-5 h-5" />, name: 'المكونات الجاهزة', count: '20+ component' },
    { icon: <GitBranch className="w-5 h-5" />, name: 'واجهات برمجية', count: '15+ endpoint' }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50" dir="rtl">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/" className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors">
                <ArrowLeft className="w-4 h-4" />
                العودة للرئيسية
              </Link>
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <Download className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold">تحميل الكود المصدري</h1>
                <p className="text-sm text-muted-foreground">{projectInfo.name}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="flex items-center gap-1">
                <Star className="w-3 h-3" />
                v{projectInfo.version}
              </Badge>
              <Badge variant="secondary" className="flex items-center gap-1">
                <Package className="w-3 h-3" />
                {projectInfo.size}
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              احصل على الكود المصدري الكامل
            </h1>
            <p className="text-xl text-blue-100 mb-8">
              قم بتنزيل المشروع الكامل وابدأ في تطويره مباشرة. يدعم اللغة العربية ويحتوي على جميع الميزات.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                <Download className="w-5 h-5 mr-2" />
                ابدأ التنزيل
              </Button>
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-blue-600">
                <Code className="w-5 h-5 mr-2" />
                عرض المعاينة
              </Button>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        {/* Project Info */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FolderOpen className="w-5 h-5" />
                  معلومات المشروع
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">الوصف</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {projectInfo.description} - منصة متكاملة لجلب الأخبار التقنية من مصادر متعددة، تلخيصها باللغة العربية، 
                    وتصنيفها بشكل ذكي باستخدام تقنيات الذكاء الاصطناعي المتقدمة. المشروع مصمم للمتخصصين واصحاب القرار في قطاع التقنية.
                  </p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium mb-2">المميزات الرئيسية</h4>
                    <ul className="space-y-1 text-sm text-muted-foreground">
                      <li>• واجهة مستخدم عربية بالكامل</li>
                      <li>• دعم RTL كامل</li>
                      <li>• تصميم متجاوب</li>
                      <li>• تحديث تلقائي يومي</li>
                      <li>• لوحة تحكم متكاملة</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">الجمهور المستهدف</h4>
                    <ul className="space-y-1 text-sm text-muted-foreground">
                      <li>• التنفيذيون في قطاع التقنية</li>
                      <li>• المطورون والمبرمجون</li>
                      <li>• متخصصو الذكاء الاصطناعي</li>
                      <li>• محللو الأعمال التقنية</li>
                      <li>• صناع القرار</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="w-5 h-5" />
                  إحصائيات سريعة
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                  <span className="text-sm font-medium">عدد الملفات</span>
                  <Badge variant="secondary">150+</Badge>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                  <span className="text-sm font-medium">حجم المشروع</span>
                  <Badge variant="secondary">{projectInfo.size}</Badge>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                  <span className="text-sm font-medium">آخر تحديث</span>
                  <Badge variant="secondary">{projectInfo.lastUpdated}</Badge>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                  <span className="text-sm font-medium">اللغات المدعومة</span>
                  <Badge variant="secondary">العربية</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Features */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-center mb-8">لماذا تختار هذا المشروع؟</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 text-white">
                    {feature.icon}
                  </div>
                  <h3 className="font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Tech Stack */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-center mb-8">تقنيات المشروع</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {techStack.map((tech, index) => (
              <Card key={index} className="text-center hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="text-2xl mb-2">{tech.icon}</div>
                  <h3 className="font-semibold text-sm">{tech.name}</h3>
                  <p className="text-xs text-muted-foreground">{tech.category}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Included Files */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-center mb-8">ماذا يتضمن التنزيل؟</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {includedFiles.map((item, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="text-blue-600">
                      {item.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-sm">{item.name}</h3>
                      <p className="text-xs text-muted-foreground">{item.count}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Download Component */}
        <SourceCodeDownloader />
      </div>

      {/* Footer */}
      <footer className="border-t bg-card mt-12">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center text-muted-foreground">
            <p>ملخص التقنية - مشروع مفتوح المصدر للجميع</p>
            <p className="text-sm mt-2">يدعم اللغة العربية والمجتمع التقني العربي</p>
          </div>
        </div>
      </footer>
    </div>
  )
}